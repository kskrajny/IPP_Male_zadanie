#ifndef DRZEWOH
#define DRZEWOH
#include "Lista.h"
// Z stuktura Historia jest sa zwiazane:
//1) drzewo historii dopuszczalnych
// - jesli historia a jest potomkiem hisotorii b, to zapis b jest prefixem zapisu a
//2) drzewa relacji
// - jesli historie a i b sa w relacji to b->ojciecR->...->ojciecR = a->ojceicR->...->ojciecR
// - "najstarszy" w relacji ma jako jedyny niezerowa wartosc energii w tej relacji
// - niech historia a jest dopuszczalna, zadna historia do ktorej mozna dojsc za pomoca a->ojciecR...
// nie musi byc dopuszczalna, oczywiscie takie historie nie sa w relacji, jest to zabieg, ktory ulatwia implementacje
//3) lista smieci(kosz)
// - jest to lista historii wyrzuconych z głownego drzewa za pomoca remove
// - pamiec historii a mozemy zwolnic dopiero po odwiedzeniu tego obiektu za pomoca b->ojciecR...,
// wtedy wszystkie historie napotkane po drodze sa przepinane do najstarszego w relacji(kompresja sciezki), zatem nie potzrebyjemy juz niedopuszczalnej relacji do niczego.(Wyjatek jest, gdy niedopuszczalna historia jest najstarsza, wtedy nie zwalniamy jej, gdyz tak jest latwiej)
// UWAGA
// zapis historii nie jest potrzebny, gdyz jest on wyznaczony jednoznacznie poprzez umieszczenie obiektu w glownym drzewie

struct Historia
{
    unsigned long long int energia;
    int dopuszczalny;
    struct Historia *ojciecR;
    struct Historia *potomkowie[4];
    struct Historia *nastsmiec;
    struct Historia *popsmiec;
};

//DRZEWO

struct Historia *stworzDrzewo();
// korzen drzewa historii

struct Historia *stworzHistorie();

int wstawdoDrzewa(struct Lista *zapis, struct Historia *h, struct Historia *kosz);
//Declare, zwraca 1 jesli malloc dal NULLa

struct Historia *znajdzwDrzewie(struct Historia *h, struct Lista *zapis);
// zwraca szukana historie lub NULLa jak po drodze w drzewie takiego napotka

void odznaczDrzewo(struct Historia *h, struct Lista *zapis);
//Remove, odcina od drzewa

#endif
