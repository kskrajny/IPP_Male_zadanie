#ifndef MAIN
#define MAIN
#include "Drzewo.h"
#include "pomocnicze.h"
#include "Lista.h"
#include "Kosz.h"
#include "Relacje.h"
#include <stdlib.h>
#include <stdio.h>

int main()
{
    int corobic = 0;
    int czyblad = 0;
    int D[7] = {68,69,67,76,65,82,69};
    int En[6] = {69,78,69,82,71,89};
    int V[5] = {86,65,76,73,68};
    int Eq[5] = {69,81,85,65,76};
    int R[6] = {82,69,77,79,86,69};
//kody ascii odpowiednich liter

    struct Historia *korzen = stworzDrzewo();
    if(korzen == NULL)
    {
        return 1;
    }
    struct Historia *kosz = stworzKosz();
    if(kosz == NULL)
    {
        free(korzen);
        return 1;
    }

    struct Historia *h = NULL;
    struct Lista *l = NULL;
    struct Lista *pom = NULL;
    struct Lista *pom1 = NULL;

    int a = getchar();
    unsigned long long int energia;

    while(a != EOF)
    {
        czyblad = 0;
// ta zmienna sygnalizuje czy wypisac ERROR
        if(a == '#')
//ignorujemy linie z # na poczatku
        {
            while(a != '\n' && a != EOF)
            {
                a = getchar();
            }
            goto koniec;
        }
        if(a == '\n')
// ignorujemy pusta linie
        {
            goto koniec;
        }
        corobic = znajdzslowo(&a, D, En, V, Eq, R);
        if(corobic != 0)
// jezeli trzeba cos zrobic
        {
            a = getchar();
            if(a < 48 || a > 51)
//sprawdzamy czy cyfra moze byc elementem historii, 48 to kod ascii 0
//jesli nie jest to pobieramy wszystko z linii + ERROR
            {
                while(a != '\n' && a != EOF)
                {
                    a = getchar();
                }
                czyblad = 1;
                goto koniec;
            }

            l = stworzListe(a-48);
            if(l == NULL)
// sprawdzamy czy udalo sie zarezerwowac pamiec
            {
                free(korzen);
                zwolnijKosz(kosz);
                return 1;
//zwracamy 1 jesli nie udalo sie zarezerwowac pamieci po zwolnieniu pamieci
            }
            pom = l;
            a = getchar();
            while(a != '\n' && a != EOF && a != ' ')
//wczytujemy historie do listy
            {               
                if(a < 48 || a > 51)
// jesli znak nie moze byc elementem historii
                {
                    while(a != '\n' && a !=EOF)
//przechodzimy do nastepnej linii + EROOR
                    {
                        a = getchar();
                    }
                    czyblad = 1;
                    goto koniec;
                }
                if(wstawdoListy(a-48, l) == 1)
// jesli zabraklo pamieci
                {
                    free(korzen);
                    zwolnijKosz(kosz);
                    zwolnijListe(pom);
                    zwolnijListe(pom1);
                    return 1;
                }
                l = l->nast;
                a = getchar();
            }
            if(a != ' ')
// jesli linia sie skonczyla, to wykonujemy ktores z ponizszych polecen
            {
		if(a != '\n')
		{
		    czyblad = 1;
		    goto koniec;
		}

                switch (corobic)
                {
                case 1:
// DECLARE historia
                    if(wstawdoDrzewa(pom, korzen, kosz) == 1)
// sprawdzamy czy udalo sie zarezerwowac pamiec
                    {
                        free(korzen);
                        zwolnijKosz(kosz);
                        zwolnijListe(pom);
                        zwolnijListe(pom1);
                        return 1;
                    }
                    printf("OK\n");
                    break;

                case 2:
// ENERGY historia
                    h = znajdzwDrzewie(korzen, pom);
// szukamy obiektu reprezentujacego historie z liscie pom
                    if(h == NULL)
// jezeli taki nie istnije w glownym drzewie ERROR
                    {
                        czyblad = 1;
                        break;
                    }
                    h = znajdzR(h);
// szukamy najstarszego obiektu w relacji, ktory ma zapisana energie
                    if(h->energia != 0)
                    {
                        printf("%llu\n", h->energia);
                    }
                    else
                    {
                        czyblad = 1;
                    }
                    break;

                case 3:
// VALID historia
                    h = znajdzwDrzewie(korzen, pom);
                    if(h == NULL)
                    {
                        printf("NO\n");
                    }
                    else
                    {
                        printf("YES\n");
                    }
                    break;

                case 5:
//REMOVE historia
                    odznaczDrzewo(korzen, pom);
                    printf("OK\n");
                    break;

                default:
//jesli zadne z powyzszych
                    czyblad = 1;
                    break;
                }
            }
            else
            {

                if(corobic == 4)
// EQUAL historia_a historia_b, pobieramy z linii historie_b
                {
                    a = getchar();
                    if(a < 48 || a > 51)
// jesli znak nie moze byc elementem historii przechodzimy do nastepnje linii + ERROR
                    {
                        while(a != '\n' && a != EOF)
                        {
                            a = getchar();
                        }
                        czyblad = 1;
                        goto koniec;
                    }
                    l = stworzListe(a-48);
                    if(l == NULL)
// sprawdzamy czy zerezerwowano pamiec
                    {
                        zwolnijKosz(kosz);
                        zwolnijListe(pom);
                        zwolnijListe(pom1);
                        return 1;
                    }
                    pom1 = l;
                    a = getchar();
                    while(a != '\n' && a != EOF)
//wczytujemy historie_b
                    {
                        if(a < 48 || a > 51)
//jesli wczytano nieopdowiedni znak przechodzimy do nastepnej linii + EROOR
                        {
                            while(a != '\n' && a != EOF)
                            {
                                a = getchar();
                            }
                            czyblad = 1;
                            goto koniec;
                        }
                        if(wstawdoListy(a-48, l) == 1)
//jesli zabraklo pamieci
                        {
                            free(korzen);
                            zwolnijKosz(kosz);
                            zwolnijListe(pom);
                            zwolnijListe(pom1);
                            return 1;
                        }
                        l = l->nast;
                        a = getchar();
                    }
		    if(a == EOF)
		    {
			czyblad = 1;
			goto koniec;
		    }	
                    int c = zrownaj(korzen, pom, pom1);
                    if(c == 1)
// 1 oznacza ze nie ma bledu
                    {
                        printf("OK\n");
                    }
                    else
                    {
                        czyblad = 1;
                        goto koniec;
                    }
                }
                if(corobic == 2)
//ENERGY historia energia
                {
                    a = getchar();
                    if(a < 48 || a > 57)
                    {
                        czyblad = 1;
                        while(a != '\n' && a != EOF)
                        {
                            a = getchar();
                        }
                        goto koniec;
                    }
                    ungetc(a, stdin);
                    energia = czyenergia();
//wczytujemy energie
                    if(energia == 0)
// jesli wczytano niepoprawne polecenie
                    {
                        czyblad = 1;
                        goto koniec;
                    }
                    int c = zmienEnergie(pom, korzen, energia);
                    if(c == 1)
// 1 oznacza ze udalo sie zmienic energie bez bledu
                    {
                        printf("OK\n");
                    }
                    else
                    {
                        czyblad = 1;
                        goto koniec;
                    }
                }
                if(corobic != 2 && corobic != 4)
                {
                    czyblad = 1;
                    while(a != '\n' && a != EOF)
                    {
                        a = getchar();
                    }
                    goto koniec;
                }
            }
        }
        else
//jesli wczytano bledne polecenie ERROR
        {
            czyblad = 1;
            while(a != '\n' && a != EOF)
//przechodzimy do nastepnej linii
            {
                a = getchar();
            }
        }
koniec:
//tutaj przechodzi goto
        zwolnijListe(pom);
        zwolnijListe(pom1);
        pom = NULL;
        pom1 = NULL;
//pobieramy pierwszy znak z nowej linii
        if(czyblad == 1)
        {
            fprintf(stderr, "ERROR\n");
        }
	if(a == EOF)
	{
	    break;
	}
	a = getchar();

    }
    free(korzen);
    zwolnijKosz(kosz);
    return 0;
}
#endif
